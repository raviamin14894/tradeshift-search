import SelectCountry from './SelectCountry';

describe('SelectCountry', () => {
  it('is truthy', () => {
    expect(SelectCountry).toBeTruthy();
  });
});
