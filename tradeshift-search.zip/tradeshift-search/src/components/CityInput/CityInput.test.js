import CityInput from './CityInput';

describe('CityInput', () => {
  it('is truthy', () => {
    expect(CityInput).toBeTruthy();
  });
});
