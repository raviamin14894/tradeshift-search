// Crosman Vlad
import React, { useState, useEffect, Fragment } from 'react';
import logo from './assets/app-icon.svg';
import './App.scss';
import { getCountries, getResults } from './services/apiService';
import SelectCountry from './components/SelectCountry';
import CityInput from './components/CityInput';

function App() {
  const [country, setCountry] = useState('');
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [countries, setCountries] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const res = await getCountries();
      setCountries(res);
    };
    fetchData();
  }, [query]);

  const handleSelect = (newCountry) => {
    console.log(newCountry);
    setCountry(newCountry);
  }

  const handleSearch = (newQuery) => {
    setQuery(newQuery);
  }

  return (
    <Fragment>
      <div className="header">
        <img src={logo} alt="logo" />
        Tradeshift Search
      </div>
      <div className="col-lg-12">
        <div className="container">
        <div className="content col-lg-12 pl-7">
          <div className="title">Tradeshift Global Search</div>
          <div className="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</div>
          <div className="col-lg-12 flex">
            <SelectCountry countries={countries} handleChange={handleSelect}/>
            <CityInput handleSearch={handleSearch} />
          </div>
        </div>
        </div>
        </div>
    </Fragment>
  );
}

export default App;
